# ClinPharm Hospital

Clinical-pharmacist workspace and student-training companion (React + Supabase, packaged for Android with Capacitor).

> **Clinical safety notice.** Decision support and education only. Screening rules are a small educational seed set — *no alert never means "safe"*. Verify every result in a licensed reference and follow your institution's protocol. Use de-identified data (initials + local reference) unless your institution has approved otherwise.

## What it does

| Area | Details |
| --- | --- |
| Patient assessment (Copilot) | 10-step workflow. Therapy, allergies, diagnoses and renal data feed the drug-related-problem screen; evidence gate blocks finalizing without a real source or an explicit "insufficient evidence". |
| Calculators | Cockcroft–Gault CrCl (actual / ideal / adjusted weight), CKD-EPI 2021 eGFR + KDIGO category, Child-Pugh, reference-based dose factor (no generic % rules). µmol/L and mg/dL. |
| Reconciliation | Parses free-text lists; shows omitted / new / changed / unchanged therapy. |
| Documentation | SOAP notes + intervention log with evidence source & level (cloud, owner-isolated). |
| Training | Trainer ↔ student linking by invite code (student consent, revocable), read-only supervisor view, written feedback with competency level. |
| Offline | Local cache + sync queue (coalescing, bounded retries, wiped on sign-out / user switch). |

## Quick start

```bash
pnpm install
cp .env.example .env     # add your Supabase URL + publishable key (never a service_role key)
pnpm dev                 # web preview
pnpm check && pnpm test  # types + unit tests (live Supabase test is skipped without env)
```

Database: run `supabase/schema.sql` (fresh project) or `supabase/migrations/0002_hardening_and_supervision.sql` (existing project) in the Supabase SQL editor — staging first — then `supabase/verify.sql`.

Android: `pnpm android:debug` (needs JDK + Android SDK).

## Project layout

```
client/src/lib/clinical.ts          calculators + evidence gate (pure, tested)
client/src/lib/clinical-engine.ts   DRP screening, medication parsing, reconciliation, SOAP
client/src/lib/supabase/            auth, repositories, sync queue, local-cache hygiene
client/src/components/workspace/    feature panels
supabase/                           schema, migrations, verification SQL
```

## Security

See `SECURITY.md`. Never commit `.env`, keystores, service-role keys or database passwords.
