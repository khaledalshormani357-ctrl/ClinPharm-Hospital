# Security & privacy

- Only the **public** Supabase URL and publishable key belong in the client. Never commit a `service_role` key, DB password, keystore or `.env`.
- All clinical tables use Row Level Security (`auth.uid() = owner_id`). Trainers get **read-only** access to a student's cases, interventions and reviews **only after the student approves** the link; patient identifiers are never shared.
- Role changes (`profiles.role`) are blocked for normal users by a trigger; promote users from the SQL editor / service role.
- Local cache (patients, sync queue) is wiped on sign-out and when a different user signs in on the same device. Android backup is disabled.
- Do not enter full names, national IDs or phone numbers. Get your institution's approval before using real patient data.
- Report vulnerabilities privately to the repository owner (GitHub → Security → Report a vulnerability).
