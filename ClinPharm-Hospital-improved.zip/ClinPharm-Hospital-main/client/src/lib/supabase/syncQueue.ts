import type { SyncQueueItem } from "./types";

const QUEUE_KEY = "clinpharm-sync-queue";
export const MAX_SYNC_ATTEMPTS = 5;

const store = (): Storage | null => (typeof localStorage === "undefined" ? null : localStorage);

function readQueue(): SyncQueueItem[] {
  try {
    return JSON.parse(store()?.getItem(QUEUE_KEY) || "[]") as SyncQueueItem[];
  } catch {
    return [];
  }
}

function writeQueue(items: SyncQueueItem[]) {
  store()?.setItem(QUEUE_KEY, JSON.stringify(items));
}

export function queueItemStatus(item: SyncQueueItem) {
  if (item.id.includes("conflict")) return "conflict" as const;
  if (item.attempts >= MAX_SYNC_ATTEMPTS || item.lastError) return "failed" as const;
  return "pending" as const;
}

/** Last-writer-wins by `updated_at`. Ties keep the local (offline) edit. */
export function resolveConflict<T extends { updated_at?: string }>(local: T, remote: T) {
  const localTime = local.updated_at ? Date.parse(local.updated_at) : 0;
  const remoteTime = remote.updated_at ? Date.parse(remote.updated_at) : 0;
  return localTime >= remoteTime ? local : remote;
}

export const syncQueue = {
  list: readQueue,

  /**
   * Adds an operation. Operations on the same entity id are coalesced instead of
   * dropped, so a later edit is never lost:
   *  create + update → create (merged payload)
   *  create + delete → nothing to sync
   *  update + delete → delete
   */
  enqueue(item: Omit<SyncQueueItem, "createdAt" | "attempts">) {
    const current = readQueue();
    const existing = current.find((entry) => entry.id === item.id);
    if (!existing) {
      const next = [...current, { ...item, attempts: 0, createdAt: Date.now() }];
      writeQueue(next);
      return next;
    }
    let next: SyncQueueItem[];
    if (item.operation === "delete") {
      next = existing.operation === "create" ? current.filter((entry) => entry.id !== item.id) : current.map((entry) => (entry.id === item.id ? { ...entry, operation: "delete" as const, payload: item.payload, attempts: 0, lastError: undefined } : entry));
    } else {
      next = current.map((entry) =>
        entry.id === item.id
          ? { ...entry, operation: entry.operation === "create" ? ("create" as const) : item.operation, payload: { ...entry.payload, ...item.payload }, attempts: 0, lastError: undefined }
          : entry,
      );
    }
    writeQueue(next);
    return next;
  },

  remove(id: string) {
    const next = readQueue().filter((item) => item.id !== id);
    writeQueue(next);
    return next;
  },

  fail(id: string, error: string) {
    const next = readQueue().map((item) => (item.id === id ? { ...item, attempts: item.attempts + 1, lastError: error } : item));
    writeQueue(next);
    return next;
  },

  /** Manual retry: lets a pharmacist re-arm an item that exhausted its attempts. */
  resetAttempts(id: string) {
    const next = readQueue().map((item) => (item.id === id ? { ...item, attempts: 0, lastError: undefined } : item));
    writeQueue(next);
    return next;
  },

  /** Items that exhausted their attempts stay in the queue (visible) but are not retried automatically. */
  async flush(executor: (item: SyncQueueItem) => Promise<void>) {
    for (const item of readQueue()) {
      if (item.attempts >= MAX_SYNC_ATTEMPTS) continue;
      try {
        await executor(item);
        this.remove(item.id);
      } catch (error) {
        this.fail(item.id, error instanceof Error ? error.message : "Sync failed");
      }
    }
    return readQueue();
  },

  clear() {
    writeQueue([]);
  },
};
