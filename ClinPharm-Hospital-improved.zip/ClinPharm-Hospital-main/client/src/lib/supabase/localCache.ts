/**
 * Local (browser/WebView) cache hygiene.
 *
 * Patient-related data is cached in localStorage for offline use. On shared
 * hospital devices that cache must never survive a sign-out or leak into
 * another account's session.
 */
export const LOCAL_CACHE_KEYS = ["clinpharm-patient-drafts", "clinpharm-cloud-patients", "clinpharm-sync-queue"] as const;
const OWNER_KEY = "clinpharm-cache-owner";

type StorageLike = Pick<Storage, "getItem" | "setItem" | "removeItem">;
const defaultStorage = (): StorageLike | null => (typeof localStorage === "undefined" ? null : localStorage);

export function purgeLocalClinicalData(storage: StorageLike | null = defaultStorage()) {
  if (!storage) return;
  for (const key of LOCAL_CACHE_KEYS) storage.removeItem(key);
  storage.removeItem(OWNER_KEY);
}

/**
 * Binds the cache to the signed-in user. If the cache belonged to someone else
 * it is wiped first. Returns true when a purge happened.
 */
export function ensureCacheOwner(userId: string, storage: StorageLike | null = defaultStorage()): boolean {
  if (!storage) return false;
  const current = storage.getItem(OWNER_KEY);
  let purged = false;
  if (current && current !== userId) {
    purgeLocalClinicalData(storage);
    purged = true;
  }
  storage.setItem(OWNER_KEY, userId);
  return purged;
}
