import { describe, expect, it } from "vitest";
import {
  adjustedBodyWeightKg,
  applyReferenceDoseFactor,
  calculateCrCl,
  calculateEgfrCkdEpi2021,
  canFinalizeRecommendation,
  childPugh,
  copilotProgress,
  gfrCategory,
  idealBodyWeightKg,
  isValidEvidenceReference,
  umolToMgDl,
} from "./clinical";

describe("calculators", () => {
  it("calculates Cockcroft-Gault CrCl with the female factor", () => {
    expect(calculateCrCl(67, 72, 1.2, "female")).toBe(52);
    expect(calculateCrCl(67, 72, 1.2, "male")).toBe(61);
  });

  it("rejects implausible or paediatric inputs instead of returning a number", () => {
    expect(calculateCrCl(10, 30, 0.5, "male")).toBeNull();
    expect(calculateCrCl(67, -1, 1.2, "male")).toBeNull();
    expect(calculateCrCl(67, 72, 0, "male")).toBeNull();
    expect(calculateCrCl(Number.NaN, 72, 1.2, "male")).toBeNull();
  });

  it("converts umol/L creatinine to mg/dL", () => {
    expect(umolToMgDl(88.4)).toBeCloseTo(1, 5);
    expect(umolToMgDl(0)).toBeNull();
  });

  it("computes CKD-EPI 2021 eGFR (50 y male, SCr 1.0 -> ~92)", () => {
    expect(calculateEgfrCkdEpi2021(50, 1.0, "male")).toBe(92);
    expect(calculateEgfrCkdEpi2021(50, 1.0, "female")!).toBeLessThan(80);
  });

  it("maps GFR to KDIGO categories", () => {
    expect([95, 75, 50, 35, 20, 10].map(gfrCategory)).toEqual(["G1", "G2", "G3a", "G3b", "G4", "G5"]);
    expect(gfrCategory(-3)).toBeNull();
  });

  it("computes ideal and adjusted body weight", () => {
    expect(idealBodyWeightKg(175, "male")).toBeCloseTo(70.5, 0);
    expect(idealBodyWeightKg(140, "female")).toBeNull();
    expect(adjustedBodyWeightKg(100, 70)).toBe(82);
  });

  it("scores Child-Pugh and assigns the class", () => {
    expect(childPugh({ bilirubinMgDl: 1, albuminGdl: 4, inr: 1.1, ascites: "none", encephalopathy: "none" })).toEqual({ score: 5, class: "A" });
    expect(childPugh({ bilirubinMgDl: 2.5, albuminGdl: 3, inr: 1.9, ascites: "mild", encephalopathy: "none" })).toEqual({ score: 9, class: "B" });
    expect(childPugh({ bilirubinMgDl: 4, albuminGdl: 2.5, inr: 2.5, ascites: "moderate-severe", encephalopathy: "grade3-4" })).toEqual({ score: 15, class: "C" });
    expect(childPugh({ bilirubinMgDl: 0, albuminGdl: 4, inr: 1, ascites: "none", encephalopathy: "none" })).toBeNull();
  });

  it("only applies a reference-based dose factor within (0, 1]", () => {
    expect(applyReferenceDoseFactor(100, 0.5)).toBe(50);
    expect(applyReferenceDoseFactor(100, 1.5)).toBeNull();
    expect(applyReferenceDoseFactor(100, 0)).toBeNull();
  });

  it("returns bounded copilot progress", () => {
    expect(copilotProgress(4, 10)).toBe(50);
    expect(copilotProgress(99, 10)).toBe(100);
    expect(copilotProgress(0, 0)).toBe(0);
  });
});

describe("evidence & finalization gate", () => {
  it("accepts real sources and rejects placeholders", () => {
    expect(isValidEvidenceReference("https://kdigo.org/guidelines/ckd-evaluation-and-management/", "Guideline")).toBe(true);
    expect(isValidEvidenceReference("https://example.org/source", "Guideline")).toBe(false);
    expect(isValidEvidenceReference("javascript:alert(1)", "Guideline")).toBe(false);
    expect(isValidEvidenceReference("not a url", "Guideline")).toBe(false);
    expect(isValidEvidenceReference("https://kdigo.org/x", "")).toBe(false);
  });

  it("blocks unverified recommendations and allows explicit 'insufficient evidence'", () => {
    const base = { isHighRisk: true, originalSourceVerified: false };
    expect(canFinalizeRecommendation({ ...base })).toBe(false);
    expect(canFinalizeRecommendation({ ...base, sourceUrl: "https://kdigo.org/x", evidenceLevel: "Guideline" })).toBe(false);
    expect(canFinalizeRecommendation({ ...base, sourceUrl: "https://kdigo.org/x", evidenceLevel: "Guideline", originalSourceVerified: true })).toBe(true);
    expect(canFinalizeRecommendation({ ...base, insufficientEvidenceAcknowledged: true })).toBe(true);
    expect(canFinalizeRecommendation({ isHighRisk: false, originalSourceVerified: false, sourceUrl: "https://kdigo.org/x", evidenceLevel: "Guideline" })).toBe(true);
  });
});
