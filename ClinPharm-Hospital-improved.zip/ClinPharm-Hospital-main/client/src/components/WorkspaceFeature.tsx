import { useEffect } from "react";
import { ShieldAlert } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useCloudClinicalRecords } from "@/hooks/useCloudClinicalRecords";
import type { DrugRelatedProblem } from "@/lib/clinical-engine";
import GuidelinesPanel from "@/components/workspace/GuidelinesPanel";
import CalculatorsPanel from "@/components/workspace/CalculatorsPanel";
import ReconciliationPanel from "@/components/workspace/ReconciliationPanel";
import AlertsPanel from "@/components/workspace/AlertsPanel";
import TrainingPanel from "@/components/workspace/TrainingPanel";
import { CasesPanel, InterventionsPanel, MedicationReviewPanel } from "@/components/workspace/DocumentationPanel";

const CLOUD_ONLY = ["Cases", "Interventions", "Clinical logbook", "Medication review", "Training hub", "Questions", "Progress"];
const HANDLED = ["Drug information", "Guidelines", "Calculators", "Reconciliation", "Alerts", ...CLOUD_ONLY];

type Props = { activeModule: string; liveProblems: DrugRelatedProblem[]; signedIn: boolean; userId: string | null };

export default function WorkspaceFeature({ activeModule, liveProblems, signedIn, userId }: Props) {
  const records = useCloudClinicalRecords();
  const { refresh } = records;
  // Home may have saved a case since this view last loaded; refresh when switching module.
  useEffect(() => { if (signedIn) void refresh(); }, [activeModule, signedIn, refresh]);

  if (!HANDLED.includes(activeModule)) return null;

  if (CLOUD_ONLY.includes(activeModule) && (!signedIn || !userId)) {
    return (
      <div className="mb-8 rounded-2xl border border-amber-200 bg-amber-50 p-6" role="status">
        <div className="flex items-start gap-3"><ShieldAlert className="h-5 w-5 shrink-0 text-amber-700" /><div><p className="font-bold text-amber-900">This workspace requires sign in</p><p className="mt-1 text-sm leading-6 text-amber-800">Sign in to open your private, user-isolated cases, interventions, reviews and training records. Calculators, reconciliation and the guideline starter list work without an account.</p></div></div>
      </div>
    );
  }

  return (
    <div className="mb-8 grid gap-6 xl:grid-cols-2">
      {(activeModule === "Guidelines" || activeModule === "Drug information") && <div className="xl:col-span-2"><GuidelinesPanel records={records} signedIn={signedIn} /></div>}
      {activeModule === "Calculators" && <div className="xl:col-span-2"><CalculatorsPanel /></div>}
      {activeModule === "Reconciliation" && <div className="xl:col-span-2"><ReconciliationPanel /></div>}
      {activeModule === "Alerts" && <AlertsPanel problems={liveProblems} />}
      {(activeModule === "Interventions" || activeModule === "Clinical logbook") && <InterventionsPanel records={records} />}
      {activeModule === "Medication review" && <MedicationReviewPanel records={records} />}
      {activeModule === "Cases" && <CasesPanel records={records} />}
      {["Training hub", "Questions", "Progress"].includes(activeModule) && userId && <TrainingPanel userId={userId} />}

      <Card className="border-slate-200 bg-white shadow-sm xl:col-span-2">
        <CardHeader><p className="eyebrow">Clinical governance</p><CardTitle className="flex items-center gap-2"><ShieldAlert className="h-5 w-5 text-teal-700" />Safety and evidence controls</CardTitle></CardHeader>
        <CardContent className="space-y-2 text-sm text-slate-600">
          <p>Every finalized recommendation needs a real source and an evidence level — or an explicit “insufficient evidence” record.</p>
          <p>High-severity problems require confirmation that the original source and the local protocol were checked.</p>
          <p>Screening rules are an educational seed set; verify every result in a licensed reference.</p>
        </CardContent>
      </Card>
    </div>
  );
}
