import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { AlertTriangle, ArrowLeft, ArrowRight, BookOpen, BrainCircuit, CheckCircle2, ClipboardCopy, ShieldAlert, Stethoscope, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { calculateCrCl, canFinalizeRecommendation, umolToMgDl, type Sex } from "@/lib/clinical";
import { EVIDENCE_LEVELS, buildSoapNote, detectDrugRelatedProblems, evidenceGate, missingSoapSections, parseMedicationList, type DrugRelatedProblem } from "@/lib/clinical-engine";

export const COPILOT_STEPS = [
  ["Patient identification", "Confirm the patient, location and clinical context"],
  ["Data collection", "Gather history, labs, allergies and current therapy"],
  ["Clinical assessment", "Frame the diagnosis, goals and patient-specific risks"],
  ["Problem identification", "Review automatically screened drug-related problems"],
  ["Drug therapy assessment", "Assess indication, efficacy, safety and adherence"],
  ["Evidence search", "Record the source, evidence level and guideline currency"],
  ["Recommendation", "Prepare a traceable recommendation for review"],
  ["Monitoring", "Define parameters, targets and follow-up timing"],
  ["Follow-up", "Track response, outcomes and unresolved issues"],
  ["Documentation", "Review the generated SOAP note and complete the case"],
] as const;

type Form = {
  patientId: string; initials: string; ward: string; age: string; sex: Sex | "";
  chiefComplaint: string; allergies: string; diagnoses: string; therapy: string; weightKg: string; scr: string; scrUnit: "mgdl" | "umol";
  assessment: string; therapyAssessment: string;
  sourceUrl: string; evidenceLevel: string; insufficientEvidence: boolean;
  recommendation: string; sourceVerified: boolean; monitoring: string; followUp: string;
};

const EMPTY: Form = {
  patientId: "", initials: "", ward: "", age: "", sex: "", chiefComplaint: "", allergies: "", diagnoses: "", therapy: "", weightKg: "", scr: "", scrUnit: "mgdl",
  assessment: "", therapyAssessment: "", sourceUrl: "", evidenceLevel: "", insufficientEvidence: false, recommendation: "", sourceVerified: false, monitoring: "", followUp: "",
};

export type AssessmentSummary = {
  crcl: number | null;
  problems: DrugRelatedProblem[];
  soapNote: string;
  sourceUrl?: string;
  evidenceLevel?: string;
  sourceVerified: boolean;
  title: string;
  data: Record<string, unknown>;
};

const splitList = (text: string) => text.split(/[\n,;،]+/).map((item) => item.trim()).filter(Boolean);
const toNumber = (text: string) => (text.trim() === "" ? Number.NaN : Number(text));
const severityStyle = { high: "border-rose-200 bg-rose-50 text-rose-900", medium: "border-amber-200 bg-amber-50 text-amber-900", low: "border-slate-200 bg-slate-50 text-slate-800" } as const;
const textareaClass = "min-h-24 w-full rounded-xl border border-slate-200 bg-white p-3 text-sm outline-none focus-visible:border-teal-500 focus-visible:ring-2 focus-visible:ring-teal-200";

// Defined at module level so inputs keep focus while typing.
function Field({ label, children, wide }: { label: string; children: ReactNode; wide?: boolean }) {
  return <label className={`field-label ${wide ? "sm:col-span-2" : ""}`}>{label}{children}</label>;
}

type Props = {
  open: boolean;
  onClose: () => void;
  onUpdate: (summary: AssessmentSummary) => void;
  onSavePatient: (draft: { id: string; initials: string; ward: string }) => Promise<void>;
  /** Resolve true when the case was saved to the cloud logbook. */
  onComplete: (summary: AssessmentSummary) => Promise<boolean>;
};

export default function CopilotDialog({ open, onClose, onUpdate, onSavePatient, onComplete }: Props) {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<Form>(EMPTY);
  const [saving, setSaving] = useState(false);
  const [completed, setCompleted] = useState(false);
  const closeRef = useRef<HTMLButtonElement>(null);
  const set = <K extends keyof Form>(key: K, value: Form[K]) => setForm((current) => ({ ...current, [key]: value }));

  const scrMgDl = form.scrUnit === "umol" ? umolToMgDl(toNumber(form.scr)) : toNumber(form.scr);
  const crcl = form.sex ? calculateCrCl(toNumber(form.age), toNumber(form.weightKg), scrMgDl ?? Number.NaN, form.sex) : null;

  const problems = useMemo(
    () => detectDrugRelatedProblems(parseMedicationList(form.therapy), { egfr: crcl, allergies: splitList(form.allergies), diagnoses: splitList(form.diagnoses) }),
    [form.therapy, form.allergies, form.diagnoses, crcl],
  );
  const isHighRisk = problems.some((problem) => problem.severity === "high");
  const hasEvidence = evidenceGate(form.sourceUrl, form.evidenceLevel);

  const soapInput = {
    subjective: [form.chiefComplaint && `Chief complaint: ${form.chiefComplaint}`, form.diagnoses && `Diagnoses: ${form.diagnoses}`, `Allergies: ${form.allergies || "not documented"}`].filter(Boolean).join("\n"),
    objective: [form.age && `Age ${form.age}${form.sex ? `, ${form.sex}` : ""}`, form.weightKg && `Weight ${form.weightKg} kg`, scrMgDl ? `SCr ${scrMgDl.toFixed(2)} mg/dL` : "", crcl !== null ? `CrCl (Cockcroft-Gault) ${crcl} mL/min` : "", form.therapy && `Current therapy:\n${form.therapy}`].filter(Boolean).join("\n"),
    assessment: [form.assessment, form.therapyAssessment, problems.length ? `Screened problems: ${problems.map((p) => `${p.title} (${p.severity})`).join("; ")}` : ""].filter(Boolean).join("\n"),
    plan: [form.recommendation && `Recommendation: ${form.recommendation}`, form.monitoring && `Monitoring: ${form.monitoring}`, form.followUp && `Follow-up: ${form.followUp}`].filter(Boolean).join("\n"),
    source: hasEvidence ? `${form.sourceUrl.trim()} (${form.evidenceLevel})` : undefined,
  };
  const soapNote = buildSoapNote(soapInput);
  const missingSections = missingSoapSections(soapInput);

  const summary = useMemo<AssessmentSummary>(
    () => ({
      crcl, problems, soapNote, sourceUrl: hasEvidence ? form.sourceUrl.trim() : undefined, evidenceLevel: hasEvidence ? form.evidenceLevel : undefined, sourceVerified: form.sourceVerified,
      title: `Pharmacist assessment${form.initials ? ` · ${form.initials.toUpperCase()}` : ""}`,
      data: { age: form.age, sex: form.sex, weightKg: form.weightKg, scrMgDl, crcl, allergies: splitList(form.allergies), diagnoses: splitList(form.diagnoses), therapy: form.therapy, problems: problems.map(({ code, severity, title, rule }) => ({ code, severity, title, rule })), insufficientEvidence: form.insufficientEvidence },
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [soapNote, crcl, problems, form.sourceVerified, form.initials, form.insufficientEvidence],
  );
  useEffect(() => { onUpdate(summary); }, [summary, onUpdate]);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    closeRef.current?.focus();
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const gate = canFinalizeRecommendation({ sourceUrl: form.sourceUrl, evidenceLevel: form.evidenceLevel, insufficientEvidenceAcknowledged: form.insufficientEvidence, isHighRisk, originalSourceVerified: form.sourceVerified });
  const canContinue =
    step === 0 ? Boolean(form.patientId.trim() && form.initials.trim()) :
    step === 5 ? hasEvidence || form.insufficientEvidence :
    step === 6 ? Boolean(form.recommendation.trim()) && gate :
    true;
  const last = step === COPILOT_STEPS.length - 1;

  const copyNote = async () => {
    try { await navigator.clipboard.writeText(soapNote); toast.success("SOAP note copied"); } catch { toast.error("Copy is not available on this device"); }
  };
  const savePatient = async () => {
    setSaving(true);
    try { await onSavePatient({ id: form.patientId.trim(), initials: form.initials.trim().toUpperCase(), ward: form.ward.trim() }); toast.success("Patient saved"); }
    catch (error) { toast.error(error instanceof Error ? error.message : "Could not save the patient"); }
    finally { setSaving(false); }
  };
  const complete = async () => {
    setSaving(true);
    try { const saved = await onComplete(summary); setCompleted(saved); if (saved) toast.success("Case saved to your logbook"); else toast.warning("Sign in to save this case to the cloud logbook. You can copy the SOAP note meanwhile."); }
    catch (error) { toast.error(error instanceof Error ? error.message : "Could not save the case"); }
    finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-[#102b2c]/40 p-4 backdrop-blur-sm">
      <div role="dialog" aria-modal="true" aria-labelledby="copilot-title" className="max-h-[92vh] w-full max-w-3xl overflow-auto rounded-3xl border border-white/50 bg-[#f8fbfa] shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-200 bg-white px-6 py-5">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-[#dff4ed] text-teal-800"><BrainCircuit className="h-5 w-5" /></div>
            <div><p className="eyebrow">Clinical Pharmacist Copilot</p><h2 id="copilot-title" className="font-display text-xl font-bold">Patient assessment</h2></div>
          </div>
          <button ref={closeRef} onClick={onClose} aria-label="Close assessment (progress is kept)" className="grid h-9 w-9 place-items-center rounded-lg hover:bg-slate-100"><X className="h-5 w-5 text-slate-500" /></button>
        </div>

        <div className="p-6">
          <ol className="mb-8 flex items-center gap-1 overflow-x-auto pb-2" aria-label="Assessment steps">
            {COPILOT_STEPS.map(([title], index) => (
              <li key={title} className="flex min-w-max items-center gap-1" aria-current={index === step ? "step" : undefined}>
                <span title={title} className={`grid h-8 w-8 place-items-center rounded-full text-xs font-bold ${index < step ? "bg-teal-700 text-white" : index === step ? "bg-[#f3c969] text-[#513c0b]" : "bg-slate-200 text-slate-500"}`}>{index < step ? <CheckCircle2 className="h-4 w-4" /> : index + 1}</span>
                {index < COPILOT_STEPS.length - 1 && <span className={`h-0.5 w-5 ${index < step ? "bg-teal-600" : "bg-slate-200"}`} />}
              </li>
            ))}
          </ol>

          <div className="rounded-2xl border border-slate-200 bg-white p-6">
            <div className="flex items-start gap-4">
              <div className="grid h-11 w-11 place-items-center rounded-xl bg-[#e9f5f0] text-teal-700"><Stethoscope className="h-5 w-5" /></div>
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.14em] text-teal-700">Step {step + 1} of {COPILOT_STEPS.length}</p>
                <h3 className="mt-1 font-display text-xl font-bold">{COPILOT_STEPS[step][0]}</h3>
                <p className="mt-2 text-sm leading-6 text-slate-500">{COPILOT_STEPS[step][1]}.</p>
              </div>
            </div>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              {step === 0 && <>
                <Field label="Hospital patient ID"><Input autoFocus value={form.patientId} onChange={(e) => set("patientId", e.target.value)} placeholder="Local reference, not the national ID" /></Field>
                <Field label="Patient initials"><Input value={form.initials} onChange={(e) => set("initials", e.target.value)} placeholder="e.g. M.A." maxLength={8} /></Field>
                <Field label="Age (years)"><Input type="number" min={0} value={form.age} onChange={(e) => set("age", e.target.value)} /></Field>
                <Field label="Sex (needed for renal formulas)"><select className="h-9 rounded-md border border-slate-200 bg-white px-2 text-sm" value={form.sex} onChange={(e) => set("sex", e.target.value as Sex | "")}><option value="">Select…</option><option value="female">Female</option><option value="male">Male</option></select></Field>
                <Field label="Ward / bed" wide><Input value={form.ward} onChange={(e) => set("ward", e.target.value)} placeholder="Cardiology · 4B-12" /></Field>
                <p className="text-xs leading-5 text-slate-500 sm:col-span-2">Privacy: use initials and a local reference only. Do not enter full names, national IDs or phone numbers.</p>
              </>}

              {step === 1 && <>
                <Field label="Chief complaint" wide><Input value={form.chiefComplaint} onChange={(e) => set("chiefComplaint", e.target.value)} placeholder="Reason for admission" /></Field>
                <Field label="Allergies (comma separated, or NKDA)"><Input value={form.allergies} onChange={(e) => set("allergies", e.target.value)} placeholder="penicillin, sulfa" /></Field>
                <Field label="Diagnoses (comma separated)"><Input value={form.diagnoses} onChange={(e) => set("diagnoses", e.target.value)} placeholder="type 2 diabetes, heart failure" /></Field>
                <Field label="Weight (kg)"><Input type="number" min={0} value={form.weightKg} onChange={(e) => set("weightKg", e.target.value)} /></Field>
                <Field label="Serum creatinine">
                  <div className="flex gap-2"><Input type="number" min={0} step="0.01" value={form.scr} onChange={(e) => set("scr", e.target.value)} /><select aria-label="Creatinine unit" className="h-9 rounded-md border border-slate-200 bg-white px-2 text-sm" value={form.scrUnit} onChange={(e) => set("scrUnit", e.target.value as "mgdl" | "umol")}><option value="mgdl">mg/dL</option><option value="umol">µmol/L</option></select></div>
                </Field>
                <Field label="Current therapy — one drug per line (name, dose, frequency)" wide><textarea className={textareaClass} value={form.therapy} onChange={(e) => set("therapy", e.target.value)} placeholder={"metformin 500 mg BID\nlisinopril 10 mg daily"} /></Field>
                <p className="rounded-xl bg-[#eaf7f2] p-3 text-xs text-teal-900 sm:col-span-2">Cockcroft–Gault CrCl: <strong>{crcl !== null ? `${crcl} mL/min` : "enter age, sex, weight and creatinine"}</strong></p>
              </>}

              {step === 2 && <Field label="Clinical assessment" wide><textarea className={textareaClass} value={form.assessment} onChange={(e) => set("assessment", e.target.value)} placeholder="Diagnosis, therapeutic goals, patient-specific risks" /></Field>}

              {step === 3 && <div className="sm:col-span-2" aria-live="polite">
                {problems.length === 0
                  ? <p className="rounded-xl bg-slate-50 p-4 text-sm text-slate-600">No problems were flagged from the entered therapy. This does <strong>not</strong> prove the regimen is safe: the rule set is a limited educational seed. Always check a licensed interaction database.</p>
                  : <ul className="space-y-3">{problems.map((problem, index) => <li key={`${problem.rule}-${index}`} className={`rounded-xl border p-4 ${severityStyle[problem.severity]}`}><div className="flex items-center gap-2"><AlertTriangle className="h-4 w-4" /><p className="text-sm font-bold">{problem.title}</p><Badge className="ml-auto border-0 bg-white/70 text-[10px] uppercase text-slate-700">{problem.code} · {problem.severity}</Badge></div><p className="mt-2 text-xs leading-5">{problem.detail}</p></li>)}</ul>}
              </div>}

              {step === 4 && <Field label="Drug therapy assessment (indication, effectiveness, safety, adherence)" wide><textarea className={textareaClass} value={form.therapyAssessment} onChange={(e) => set("therapyAssessment", e.target.value)} /></Field>}

              {step === 5 && <div className="space-y-4 rounded-xl border border-cyan-200 bg-cyan-50 p-4 sm:col-span-2">
                <div className="flex gap-3"><BookOpen className="h-5 w-5 shrink-0 text-cyan-700" /><div><p className="text-sm font-bold text-cyan-900">Evidence gate</p><p className="mt-1 text-xs leading-5 text-cyan-800">A recommendation needs a real source URL and an evidence level — or an explicit “insufficient evidence” statement. Placeholder links are rejected.</p></div></div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Source URL"><Input value={form.sourceUrl} onChange={(e) => set("sourceUrl", e.target.value)} placeholder="https://…" inputMode="url" /></Field>
                  <Field label="Evidence level"><select className="h-9 rounded-md border border-slate-200 bg-white px-2 text-sm" value={form.evidenceLevel} onChange={(e) => set("evidenceLevel", e.target.value)}><option value="">Select…</option>{EVIDENCE_LEVELS.map((level) => <option key={level}>{level}</option>)}</select></Field>
                </div>
                {form.sourceUrl.trim() !== "" && !hasEvidence && <p className="text-xs font-semibold text-rose-700">Enter a valid https:// source and select an evidence level.</p>}
                <label className="flex items-center gap-2 text-xs font-semibold text-cyan-900"><input type="checkbox" checked={form.insufficientEvidence} onChange={(e) => set("insufficientEvidence", e.target.checked)} /> No suitable evidence found — record “Insufficient evidence”</label>
              </div>}

              {step === 6 && <div className="space-y-4 sm:col-span-2">
                <Field label="Recommendation" wide><textarea className={textareaClass} value={form.recommendation} onChange={(e) => set("recommendation", e.target.value)} /></Field>
                {isHighRisk && <div className="rounded-xl border border-rose-200 bg-rose-50 p-4"><div className="flex gap-3"><ShieldAlert className="h-5 w-5 shrink-0 text-rose-600" /><div><p className="text-sm font-bold text-rose-900">HIGH-RISK CLINICAL DECISION</p><p className="mt-1 text-xs leading-5 text-rose-800">High-severity problems were flagged. Verify the original source and the institutional protocol before accepting this recommendation.</p>
                  <label className="mt-3 flex items-center gap-2 text-xs font-semibold text-rose-900"><input type="checkbox" checked={form.sourceVerified} onChange={(e) => set("sourceVerified", e.target.checked)} /> I have verified the original source and the local protocol</label></div></div></div>}
                {!gate && <p className="text-xs font-semibold text-rose-700">{!hasEvidence && !form.insufficientEvidence ? "Go back to step 6 and add a source (or mark insufficient evidence)." : "Confirm source verification to continue."}</p>}
              </div>}

              {step === 7 && <Field label="Monitoring parameters, targets and timing" wide><textarea className={textareaClass} value={form.monitoring} onChange={(e) => set("monitoring", e.target.value)} /></Field>}
              {step === 8 && <Field label="Follow-up plan and unresolved issues" wide><textarea className={textareaClass} value={form.followUp} onChange={(e) => set("followUp", e.target.value)} /></Field>}

              {step === 9 && <div className="space-y-3 sm:col-span-2">
                <pre className="max-h-72 overflow-auto whitespace-pre-wrap rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs leading-5 text-slate-700">{soapNote}</pre>
                {missingSections.length > 0 && <p className="text-xs font-semibold text-rose-700">Incomplete sections: {missingSections.join(", ")}. Go back and complete them.</p>}
                {completed && <p className="text-xs font-semibold text-teal-700">Saved to your cloud logbook.</p>}
              </div>}
            </div>
          </div>

          <div className="mt-5 flex flex-wrap items-center justify-between gap-2">
            <Button variant="ghost" onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0} className="rounded-xl"><ArrowLeft className="mr-2 h-4 w-4" /> Previous</Button>
            <div className="flex flex-wrap gap-2">
              {step === 9 && <Button variant="outline" onClick={() => void copyNote()} className="rounded-xl"><ClipboardCopy className="mr-2 h-4 w-4" />Copy SOAP</Button>}
              <Button variant="outline" onClick={() => void savePatient()} disabled={saving || !form.patientId.trim() || !form.initials.trim()} className="rounded-xl">Save patient</Button>
              {last
                ? <Button onClick={() => void complete()} disabled={saving || missingSections.length > 0 || !gate} className="rounded-xl bg-[#102b2c] text-white hover:bg-[#1a4a4b]">Complete &amp; save</Button>
                : <Button onClick={() => setStep((s) => Math.min(COPILOT_STEPS.length - 1, s + 1))} disabled={!canContinue} className="rounded-xl bg-[#102b2c] text-white hover:bg-[#1a4a4b]">Continue<ArrowRight className="ml-2 h-4 w-4" /></Button>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
