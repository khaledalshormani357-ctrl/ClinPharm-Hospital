import { useState } from "react";
import { Calculator, History } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { adjustedBodyWeightKg, applyReferenceDoseFactor, calculateCrCl, calculateEgfrCkdEpi2021, childPugh, gfrCategory, idealBodyWeightKg, isValidEvidenceReference, umolToMgDl, type Sex } from "@/lib/clinical";
import { recordCalculation } from "@/lib/clinical-engine";

const num = (text: string) => (text.trim() === "" ? Number.NaN : Number(text));
const select = "h-9 rounded-md border border-slate-200 bg-white px-2 text-sm";

function Result({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return <div className="rounded-xl bg-[#eaf7f2] p-3"><p className="text-[10px] font-bold uppercase tracking-wider text-teal-800">{label}</p><p className="mt-1 font-display text-2xl font-bold text-slate-900">{value}</p>{hint && <p className="mt-1 text-xs text-slate-600">{hint}</p>}</div>;
}

export default function CalculatorsPanel() {
  const [age, setAge] = useState("");
  const [sex, setSex] = useState<Sex | "">("");
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [scr, setScr] = useState("");
  const [unit, setUnit] = useState<"mgdl" | "umol">("mgdl");
  const [dose, setDose] = useState("");
  const [factorPct, setFactorPct] = useState("");
  const [source, setSource] = useState("");
  const [cp, setCp] = useState({ bili: "", alb: "", inr: "", ascites: "none" as "none" | "mild" | "moderate-severe", enc: "none" as "none" | "grade1-2" | "grade3-4" });
  const [history, setHistory] = useState<Array<{ type: string; value: string; timestamp: number }>>([]);

  const scrMgDl = unit === "umol" ? umolToMgDl(num(scr)) ?? Number.NaN : num(scr);
  const ready = sex !== "";
  const actual = ready ? calculateCrCl(num(age), num(weight), scrMgDl, sex) : null;
  const ibw = ready ? idealBodyWeightKg(num(height), sex) : null;
  const adjBw = ibw !== null ? adjustedBodyWeightKg(num(weight), ibw) : null;
  const crclIbw = ready && ibw !== null ? calculateCrCl(num(age), ibw, scrMgDl, sex) : null;
  const crclAdj = ready && adjBw !== null ? calculateCrCl(num(age), adjBw, scrMgDl, sex) : null;
  const egfr = ready ? calculateEgfrCkdEpi2021(num(age), scrMgDl, sex) : null;
  const category = egfr !== null ? gfrCategory(egfr) : null;

  const sourceOk = isValidEvidenceReference(source, "reference");
  const adjusted = applyReferenceDoseFactor(num(dose), num(factorPct) / 100);
  const pugh = childPugh({ bilirubinMgDl: num(cp.bili), albuminGdl: num(cp.alb), inr: num(cp.inr), ascites: cp.ascites, encephalopathy: cp.enc });

  const save = (type: string, value: string) => setHistory((items) => recordCalculation(items, type, value));

  return (
    <div className="space-y-6">
      <Card className="border-slate-200 shadow-sm">
        <CardHeader><p className="eyebrow">Clinical calculators</p><CardTitle className="flex items-center gap-2"><Calculator className="h-5 w-5 text-teal-700" />Renal function</CardTitle></CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-3">
            <label className="field-label">Age (years)<Input type="number" min={0} value={age} onChange={(e) => setAge(e.target.value)} /></label>
            <label className="field-label">Sex<select className={select} value={sex} onChange={(e) => setSex(e.target.value as Sex | "")}><option value="">Select…</option><option value="female">Female</option><option value="male">Male</option></select></label>
            <label className="field-label">Weight (kg)<Input type="number" min={0} value={weight} onChange={(e) => setWeight(e.target.value)} /></label>
            <label className="field-label">Height (cm, optional)<Input type="number" min={0} value={height} onChange={(e) => setHeight(e.target.value)} /></label>
            <label className="field-label sm:col-span-2">Serum creatinine<div className="flex gap-2"><Input type="number" min={0} step="0.01" value={scr} onChange={(e) => setScr(e.target.value)} /><select aria-label="Creatinine unit" className={select} value={unit} onChange={(e) => setUnit(e.target.value as "mgdl" | "umol")}><option value="mgdl">mg/dL</option><option value="umol">µmol/L</option></select></div></label>
          </div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4" aria-live="polite">
            <Result label="CrCl · actual weight" value={actual !== null ? `${actual} mL/min` : "—"} hint="Cockcroft–Gault" />
            <Result label="CrCl · ideal weight" value={crclIbw !== null ? `${crclIbw} mL/min` : "—"} hint={ibw !== null ? `IBW ${ibw} kg` : "needs height ≥ 152 cm"} />
            <Result label="CrCl · adjusted weight" value={crclAdj !== null ? `${crclAdj} mL/min` : "—"} hint={adjBw !== null ? `AdjBW ${adjBw} kg` : "needs height"} />
            <Result label="eGFR CKD-EPI 2021" value={egfr !== null ? `${egfr}` : "—"} hint={category ? `mL/min/1.73 m² · ${category}` : undefined} />
          </div>
          <p className="mt-3 text-xs leading-5 text-slate-500">Which weight to use (actual, ideal or adjusted) and whether to use CrCl or eGFR for a given drug is a clinical decision — follow the drug&apos;s labelled method. Results are not shown for implausible inputs or patients under 18.</p>
          <Button variant="outline" disabled={actual === null && egfr === null} onClick={() => save("renal function", `CrCl ${actual ?? "—"} mL/min · eGFR ${egfr ?? "—"}`)} className="mt-3 h-8 rounded-lg text-xs">Save to history</Button>
        </CardContent>
      </Card>

      <Card className="border-slate-200 shadow-sm">
        <CardHeader><CardTitle>Dose adjustment from a reference</CardTitle></CardHeader>
        <CardContent>
          <p className="mb-4 text-xs leading-5 text-slate-500">There is no universal “reduce by 50%” rule: renal and hepatic adjustments are drug-specific. Enter the factor stated by your reference (label, Renal Drug Handbook, Lexicomp…) and its link.</p>
          <div className="grid gap-4 sm:grid-cols-3">
            <label className="field-label">Current dose (mg)<Input type="number" min={0} value={dose} onChange={(e) => setDose(e.target.value)} /></label>
            <label className="field-label">Reference dose factor (% of usual)<Input type="number" min={1} max={100} value={factorPct} onChange={(e) => setFactorPct(e.target.value)} /></label>
            <label className="field-label">Reference URL<Input value={source} onChange={(e) => setSource(e.target.value)} placeholder="https://…" inputMode="url" /></label>
          </div>
          <div className="mt-4"><Result label="Adjusted dose (for review)" value={sourceOk && adjusted !== null ? `${adjusted} mg` : "—"} hint={!sourceOk ? "A valid source link is required to show a result" : "Verify against the original reference before use"} /></div>
          <Button variant="outline" disabled={!sourceOk || adjusted === null} onClick={() => save("reference dose adjustment", `${dose} mg → ${adjusted} mg (${source.trim()})`)} className="mt-3 h-8 rounded-lg text-xs">Save to history</Button>
        </CardContent>
      </Card>

      <Card className="border-slate-200 shadow-sm">
        <CardHeader><CardTitle>Child-Pugh score</CardTitle></CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-3">
            <label className="field-label">Bilirubin (mg/dL)<Input type="number" min={0} step="0.1" value={cp.bili} onChange={(e) => setCp({ ...cp, bili: e.target.value })} /></label>
            <label className="field-label">Albumin (g/dL)<Input type="number" min={0} step="0.1" value={cp.alb} onChange={(e) => setCp({ ...cp, alb: e.target.value })} /></label>
            <label className="field-label">INR<Input type="number" min={0} step="0.1" value={cp.inr} onChange={(e) => setCp({ ...cp, inr: e.target.value })} /></label>
            <label className="field-label">Ascites<select className={select} value={cp.ascites} onChange={(e) => setCp({ ...cp, ascites: e.target.value as typeof cp.ascites })}><option value="none">None</option><option value="mild">Mild / controlled</option><option value="moderate-severe">Moderate–severe</option></select></label>
            <label className="field-label">Encephalopathy<select className={select} value={cp.enc} onChange={(e) => setCp({ ...cp, enc: e.target.value as typeof cp.enc })}><option value="none">None</option><option value="grade1-2">Grade 1–2</option><option value="grade3-4">Grade 3–4</option></select></label>
          </div>
          <div className="mt-4"><Result label="Child-Pugh" value={pugh ? `${pugh.score} points · class ${pugh.class}` : "—"} /></div>
          <Button variant="outline" disabled={!pugh} onClick={() => pugh && save("Child-Pugh", `${pugh.score} points · class ${pugh.class}`)} className="mt-3 h-8 rounded-lg text-xs">Save to history</Button>
        </CardContent>
      </Card>

      <Card className="border-slate-200 shadow-sm">
        <CardHeader><CardTitle className="flex items-center gap-2"><History className="h-4 w-4 text-teal-700" />Calculation history (this session)</CardTitle></CardHeader>
        <CardContent>{history.length === 0 ? <p className="text-sm text-slate-500">Nothing saved yet. History is kept in memory only and is not stored.</p> : <ul className="space-y-2 text-sm">{history.map((item) => <li key={item.timestamp} className="rounded-lg bg-slate-50 p-3"><strong>{item.type}</strong> — {item.value}<span className="ml-2 text-xs text-slate-400">{new Date(item.timestamp).toLocaleTimeString()}</span></li>)}</ul>}</CardContent>
      </Card>
    </div>
  );
}
