import { useCallback, useEffect, useState } from "react";
import { Check, ClipboardCopy, GraduationCap, UserPlus, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supervisionRepository, type Competency, type FeedbackRecord, type MySupervisor, type SupervisedStudent } from "@/lib/supabase/supervisionRepository";

const fail = (error: unknown) => toast.error(error instanceof Error ? error.message : "Something went wrong");
const COMPETENCY: Array<[Competency, string]> = [["not_yet", "Not yet competent"], ["developing", "Developing"], ["competent", "Competent"], ["excellent", "Excellent"]];
const statusStyle = { pending: "bg-amber-100 text-amber-800", active: "bg-teal-100 text-teal-800", revoked: "bg-slate-100 text-slate-600" } as const;
type Overview = Awaited<ReturnType<typeof supervisionRepository.studentOverview>>;

export default function TrainingPanel({ userId }: { userId: string }) {
  const [code, setCode] = useState<string | null>(null);
  const [role, setRole] = useState<string>("");
  const [supervisors, setSupervisors] = useState<MySupervisor[]>([]);
  const [students, setStudents] = useState<SupervisedStudent[]>([]);
  const [inviteInput, setInviteInput] = useState("");
  const [selected, setSelected] = useState<SupervisedStudent | null>(null);
  const [overview, setOverview] = useState<Overview | null>(null);
  const [feedback, setFeedback] = useState<FeedbackRecord[]>([]);
  const [comment, setComment] = useState("");
  const [competency, setCompetency] = useState<Competency | "">("");

  const load = useCallback(async () => {
    try {
      const [profile, mine, theirs] = await Promise.all([supervisionRepository.myInviteCode(userId), supervisionRepository.supervisors(), supervisionRepository.students()]);
      setCode(profile.invite_code); setRole(profile.role); setSupervisors(mine); setStudents(theirs);
    } catch (error) { fail(error); }
  }, [userId]);
  useEffect(() => { void load(); }, [load]);

  const openStudent = async (student: SupervisedStudent) => {
    setSelected(student); setOverview(null);
    try { const [data, notes] = await Promise.all([student.status === "active" ? supervisionRepository.studentOverview(student.student_id) : Promise.resolve(null), supervisionRepository.feedbackFor(student.student_id)]); setOverview(data); setFeedback(notes); } catch (error) { fail(error); }
  };

  const request = async () => { try { await supervisionRepository.requestSupervision(inviteInput); setInviteInput(""); toast.success("Request sent — the student must approve it"); await load(); } catch (error) { fail(error); } };
  const respond = async (linkId: string, status: "active" | "revoked") => { try { await supervisionRepository.setStatus(linkId, status); await load(); } catch (error) { fail(error); } };
  const send = async () => {
    if (!selected) return;
    try { await supervisionRepository.addFeedback({ student_id: selected.student_id, comment: comment.trim(), competency: competency || null }); setComment(""); setCompetency(""); setFeedback(await supervisionRepository.feedbackFor(selected.student_id)); toast.success("Feedback sent"); } catch (error) { fail(error); }
  };
  const copyCode = async () => { if (!code) return; try { await navigator.clipboard.writeText(code); toast.success("Code copied"); } catch { toast.error("Copy is not available"); } };
  const canSupervise = role !== "" && role !== "pharmacy_student";

  return (
    <div className="space-y-6 xl:col-span-2">
      <Card className="border-slate-200 shadow-sm">
        <CardHeader><p className="eyebrow">Student training</p><CardTitle className="flex items-center gap-2"><GraduationCap className="h-5 w-5 text-teal-700" />My training &amp; supervisors</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap items-center gap-3 rounded-xl bg-slate-50 p-4">
            <div><p className="text-xs font-bold text-slate-600">My invite code</p><p className="mt-1 font-mono text-lg font-bold tracking-widest">{code ?? "—"}</p></div>
            <Button variant="outline" onClick={() => void copyCode()} disabled={!code} className="rounded-xl"><ClipboardCopy className="mr-2 h-4 w-4" />Copy</Button>
            <p className="max-w-md text-xs leading-5 text-slate-500">Give this code to your trainer. They send a request; nothing is shared until you approve it, and you can revoke access at any time. Trainers see your cases, interventions and reviews (read-only) — never your patient list.</p>
          </div>
          {supervisors.length === 0 ? <p className="text-sm text-slate-500">No supervisors linked yet.</p> : (
            <ul className="space-y-2">{supervisors.map((s) => <li key={s.link_id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 p-3 text-sm"><span className="font-semibold">{s.display_name ?? "Trainer"} <Badge className={`ml-2 border-0 text-[10px] ${statusStyle[s.status]}`}>{s.status}</Badge></span>
              <span className="flex gap-2">{s.status !== "active" && <Button size="sm" onClick={() => void respond(s.link_id, "active")} className="h-8 rounded-lg bg-teal-700 text-white"><Check className="mr-1 h-3.5 w-3.5" />Approve</Button>}{s.status !== "revoked" && <Button size="sm" variant="outline" onClick={() => void respond(s.link_id, "revoked")} className="h-8 rounded-lg"><X className="mr-1 h-3.5 w-3.5" />{s.status === "pending" ? "Decline" : "Revoke"}</Button>}</span></li>)}</ul>
          )}
        </CardContent>
      </Card>

      {canSupervise && (
        <Card className="border-slate-200 shadow-sm">
          <CardHeader><CardTitle>Trainer view — my students</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap gap-2"><Input className="max-w-xs" value={inviteInput} onChange={(e) => setInviteInput(e.target.value)} placeholder="Student invite code" aria-label="Student invite code" /><Button onClick={() => void request()} disabled={inviteInput.trim().length < 6} className="rounded-xl bg-[#102b2c] text-white"><UserPlus className="mr-2 h-4 w-4" />Request supervision</Button></div>
            <ul className="space-y-2">{students.map((s) => <li key={s.link_id}><button onClick={() => void openStudent(s)} className={`flex w-full items-center justify-between rounded-xl border p-3 text-left text-sm ${selected?.link_id === s.link_id ? "border-teal-400 bg-teal-50" : "border-slate-200 bg-white"}`}><span className="font-semibold">{s.display_name ?? "Student"}</span><Badge className={`border-0 text-[10px] ${statusStyle[s.status]}`}>{s.status}</Badge></button></li>)}{students.length === 0 && <li className="text-sm text-slate-500">No students yet.</li>}</ul>

            {selected && (
              <div className="rounded-2xl border border-slate-200 p-4">
                <h3 className="font-display text-base font-bold">{selected.display_name ?? "Student"}</h3>
                {selected.status !== "active" ? <p className="mt-2 text-sm text-slate-500">Waiting for the student to approve access.</p> : !overview ? <p className="mt-2 text-sm text-slate-500">Loading…</p> : (
                  <div className="mt-3 grid gap-4 md:grid-cols-3 text-xs">
                    <div><p className="font-bold text-slate-700">Cases ({overview.cases.length})</p><ul className="mt-1 space-y-1 text-slate-600">{overview.cases.map((c) => <li key={c.id}>{c.title} · step {(c.current_step ?? 0) + 1}/10{c.source_verified ? " ✓" : ""}</li>)}</ul></div>
                    <div><p className="font-bold text-slate-700">Interventions ({overview.interventions.length})</p><ul className="mt-1 space-y-1 text-slate-600">{overview.interventions.map((i) => <li key={i.id}>{i.intervention_type} · {i.status}</li>)}</ul></div>
                    <div><p className="font-bold text-slate-700">Medication reviews ({overview.reviews.length})</p><ul className="mt-1 space-y-1 text-slate-600">{overview.reviews.map((r) => <li key={r.id}>{r.indication} · {r.status}</li>)}</ul></div>
                  </div>
                )}
                {selected.status === "active" && <div className="mt-4 space-y-2"><label className="field-label">Feedback<textarea className="min-h-20 w-full rounded-xl border border-slate-200 p-3 text-sm" value={comment} onChange={(e) => setComment(e.target.value)} maxLength={2000} /></label>
                  <div className="flex flex-wrap items-center gap-2"><select aria-label="Competency level" className="h-9 rounded-md border border-slate-200 bg-white px-2 text-sm" value={competency} onChange={(e) => setCompetency(e.target.value as Competency | "")}><option value="">Competency (optional)</option>{COMPETENCY.map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select><Button onClick={() => void send()} disabled={!comment.trim()} className="rounded-xl bg-[#102b2c] text-white">Send feedback</Button></div></div>}
                {feedback.length > 0 && <ul className="mt-4 space-y-2">{feedback.map((f) => <li key={f.id} className="rounded-lg bg-slate-50 p-3 text-xs"><p className="text-slate-700">{f.comment}</p><p className="mt-1 text-[10px] text-slate-400">{new Date(f.created_at).toLocaleString()}{f.competency ? ` · ${COMPETENCY.find(([v]) => v === f.competency)?.[1]}` : ""}</p></li>)}</ul>}
              </div>
            )}
          </CardContent>
        </Card>
      )}
      <p className="text-xs leading-5 text-slate-500">Question bank and competency tracking are on the roadmap; the feedback above is stored with your account and visible to both trainer and student.</p>
    </div>
  );
}
