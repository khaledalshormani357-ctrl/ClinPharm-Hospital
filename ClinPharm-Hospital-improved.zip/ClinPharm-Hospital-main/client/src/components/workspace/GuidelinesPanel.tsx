import { useEffect, useMemo, useState } from "react";
import { BookOpen, Search } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { useCloudClinicalRecords } from "@/hooks/useCloudClinicalRecords";

type Row = { organization: string; title: string; year: string; tier: string; status: string; url: string; checkedOn?: string };

// Built-in starter list, used when signed out. "checkedOn" is set only where the
// edition was confirmed; everything else must be verified at the source.
const STARTER_GUIDELINES: Row[] = [
  { organization: "ADA", title: "Standards of Care in Diabetes—2026", year: "2026", tier: "Tier 1", status: "CURRENT EDITION", url: "https://diabetesjournals.org/care/issue/49/Supplement_1", checkedOn: "2026-10-09" },
  { organization: "KDIGO", title: "CKD Evaluation & Management", year: "2024", tier: "Tier 1", status: "VERIFY CURRENCY", url: "https://kdigo.org/guidelines/ckd-evaluation-and-management/" },
  { organization: "FDA", title: "Drug Safety Communications", year: "—", tier: "Tier 2", status: "LIVE SOURCE", url: "https://www.fda.gov/drugs/drug-safety-and-availability" },
];

type Records = ReturnType<typeof useCloudClinicalRecords>;

export default function GuidelinesPanel({ records, signedIn }: { records: Records; signedIn: boolean }) {
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const { searchGuidelines } = records;

  useEffect(() => { const timer = setTimeout(() => setDebounced(query), 300); return () => clearTimeout(timer); }, [query]);
  useEffect(() => { if (signedIn) void searchGuidelines(debounced).catch(() => undefined); }, [signedIn, debounced, searchGuidelines]);

  const cloudRows: Row[] = records.guidelines.map((row) => ({ organization: row.organization, title: row.title, year: String(row.year ?? "—"), tier: row.tier, status: row.status, url: row.source_url }));
  const base = signedIn && cloudRows.length > 0 ? cloudRows : STARTER_GUIDELINES;
  const rows = useMemo(() => base.filter((row) => `${row.organization} ${row.title}`.toLowerCase().includes(query.toLowerCase())), [base, query]);

  return (
    <Card className="border-slate-200 shadow-sm">
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div><p className="eyebrow">Evidence center</p><CardTitle className="mt-1 flex items-center gap-2"><BookOpen className="h-5 w-5 text-teal-700" />Guideline finder</CardTitle></div>
          <Badge className="border-0 bg-[#eaf7f2] text-teal-800">{signedIn && cloudRows.length > 0 ? "Your institution list" : "Starter list"}</Badge>
        </div>
        <div className="relative mt-4"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" /><Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search organization or guideline" className="pl-9" aria-label="Search evidence sources" /></div>
      </CardHeader>
      <CardContent className="space-y-3">
        {rows.map((row) => (
          <div key={`${row.organization}-${row.title}-${row.year}`} className="rounded-xl border border-slate-200 p-4">
            <p className="text-xs font-bold uppercase tracking-wider text-teal-700">{row.organization} · {row.tier}</p>
            <p className="mt-1 text-sm font-bold text-slate-800">{row.title}</p>
            <p className="mt-1 text-xs text-slate-500">Year: {row.year} · Status: {row.status}{row.checkedOn ? ` · checked ${row.checkedOn}` : ""}</p>
            <a className="mt-3 inline-block text-xs font-bold text-teal-700 underline" href={row.url} target="_blank" rel="noreferrer noopener">Open original source</a>
          </div>
        ))}
        {rows.length === 0 && <p className="py-5 text-sm text-slate-500">Insufficient evidence / source not available.</p>}
        <p className="text-xs leading-5 text-slate-500">Guideline editions change every year. Confirm the edition on the publisher&apos;s site before citing it; admins can load your institution&apos;s list into the <code>guidelines</code> table.</p>
      </CardContent>
    </Card>
  );
}
