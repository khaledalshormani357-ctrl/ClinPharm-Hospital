import { useState } from "react";
import { AlertTriangle, ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { DrugRelatedProblem } from "@/lib/clinical-engine";

export default function AlertsPanel({ problems }: { problems: DrugRelatedProblem[] }) {
  const [acknowledged, setAcknowledged] = useState<Set<string>>(new Set());
  const keyOf = (problem: DrugRelatedProblem, index: number) => `${problem.rule}-${index}`;
  const toggle = (key: string) => setAcknowledged((current) => { const next = new Set(current); next.has(key) ? next.delete(key) : next.add(key); return next; });

  return (
    <Card className="border-rose-200 bg-rose-50/50 shadow-sm xl:col-span-2">
      <CardHeader><p className="eyebrow text-rose-700">Safety center</p><CardTitle className="flex items-center gap-2 text-rose-900"><ShieldAlert className="h-5 w-5 text-rose-600" />Alerts from the current assessment</CardTitle></CardHeader>
      <CardContent className="space-y-3" aria-live="polite">
        {problems.length === 0 && <p className="rounded-xl bg-white p-4 text-sm text-slate-600">No alerts. Alerts are produced from the therapy entered in a patient assessment. The rule set is a limited seed: no alert never means the regimen is safe.</p>}
        {problems.map((problem, index) => {
          const key = keyOf(problem, index);
          const done = acknowledged.has(key);
          return (
            <div key={key} className={`rounded-xl border bg-white p-4 ${problem.severity === "high" ? "border-rose-200" : "border-amber-200"} ${done ? "opacity-60" : ""}`}>
              <div className="flex gap-3"><AlertTriangle className={`h-5 w-5 shrink-0 ${problem.severity === "high" ? "text-rose-600" : "text-amber-600"}`} />
                <div className="flex-1"><p className="text-sm font-bold">{problem.title} <span className="text-[10px] font-semibold uppercase text-slate-400">{problem.code} · {problem.severity}</span></p><p className="mt-1 text-xs leading-5 text-slate-600">{problem.detail}</p>
                  <Button onClick={() => toggle(key)} variant="outline" className="mt-3 h-8 rounded-lg text-xs">{done ? "Undo review mark" : "Mark as reviewed"}</Button></div></div>
            </div>
          );
        })}
        {problems.length > 0 && <p className="text-[11px] text-slate-500">“Reviewed” marks are for this session only. Document actions in an intervention note.</p>}
      </CardContent>
    </Card>
  );
}
