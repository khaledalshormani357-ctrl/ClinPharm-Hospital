import { useMemo, useState } from "react";
import { ClipboardCopy, FlaskConical } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { parseMedicationList, reconcileMedications, type Medication } from "@/lib/clinical-engine";

const area = "min-h-32 w-full rounded-xl border border-slate-200 bg-white p-3 text-sm outline-none focus-visible:border-teal-500 focus-visible:ring-2 focus-visible:ring-teal-200";
const describe = (m: Medication) => m.raw?.trim() || m.name;

export default function ReconciliationPanel() {
  const [home, setHome] = useState("");
  const [orders, setOrders] = useState("");
  const result = useMemo(() => reconcileMedications(parseMedicationList(home), parseMedicationList(orders)), [home, orders]);
  const changed = result.continued.filter((pair) => pair.doseChanged || pair.frequencyChanged);
  const unchanged = result.continued.filter((pair) => !pair.doseChanged && !pair.frequencyChanged);
  const empty = !home.trim() && !orders.trim();

  const summary = [
    `OMITTED (home, not ordered): ${result.omitted.map(describe).join("; ") || "none"}`,
    `NEW (ordered, not at home): ${result.newTherapy.map(describe).join("; ") || "none"}`,
    `CHANGED: ${changed.map((p) => `${describe(p.home)} → ${describe(p.inpatient)}`).join("; ") || "none"}`,
    `CONTINUED UNCHANGED: ${unchanged.map((p) => p.home.name).join("; ") || "none"}`,
  ].join("\n");

  const copy = async () => { try { await navigator.clipboard.writeText(summary); toast.success("Summary copied"); } catch { toast.error("Copy is not available on this device"); } };

  return (
    <Card className="border-slate-200 shadow-sm">
      <CardHeader><p className="eyebrow">Medication reconciliation</p><CardTitle className="flex items-center gap-2"><FlaskConical className="h-5 w-5 text-teal-700" />Admission / discharge comparison</CardTitle></CardHeader>
      <CardContent>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="field-label">Home medication list (one per line)<textarea value={home} onChange={(e) => setHome(e.target.value)} className={area} placeholder={"metformin 500 mg BID\nlisinopril 10 mg daily"} /></label>
          <label className="field-label">Current orders (one per line)<textarea value={orders} onChange={(e) => setOrders(e.target.value)} className={area} placeholder={"lisinopril 20 mg daily\natorvastatin 20 mg nightly"} /></label>
        </div>
        {empty ? <p className="mt-4 text-sm text-slate-500">Enter both lists to compare them. Names are matched case-insensitively; doses and frequencies are compared for continued drugs.</p> : (
          <div className="mt-4 grid gap-3 sm:grid-cols-2" aria-live="polite">
            <Group title="Omitted — home drug not ordered" tone="rose" items={result.omitted.map(describe)} note="Intentional? Document the reason, otherwise escalate." />
            <Group title="New — ordered, not taken at home" tone="amber" items={result.newTherapy.map(describe)} note="Confirm indication and duration." />
            <Group title="Continued with a change" tone="violet" items={changed.map((p) => `${describe(p.home)} → ${describe(p.inpatient)}`)} note="Dose or frequency differs: confirm it is intentional." />
            <Group title="Continued unchanged" tone="teal" items={unchanged.map((p) => p.home.name)} />
          </div>
        )}
        <Button variant="outline" onClick={() => void copy()} disabled={empty} className="mt-4 rounded-xl"><ClipboardCopy className="mr-2 h-4 w-4" />Copy summary</Button>
      </CardContent>
    </Card>
  );
}

function Group({ title, items, tone, note }: { title: string; items: string[]; tone: "rose" | "amber" | "violet" | "teal"; note?: string }) {
  const palette = { rose: "border-rose-200 bg-rose-50", amber: "border-amber-200 bg-amber-50", violet: "border-violet-200 bg-violet-50", teal: "border-teal-200 bg-teal-50" }[tone];
  return <div className={`rounded-xl border p-4 ${palette}`}><p className="text-xs font-bold text-slate-800">{title} ({items.length})</p>{items.length === 0 ? <p className="mt-2 text-xs text-slate-500">None</p> : <ul className="mt-2 list-disc space-y-1 pl-4 text-xs text-slate-700">{items.map((item) => <li key={item}>{item}</li>)}</ul>}{note && items.length > 0 && <p className="mt-2 text-[11px] text-slate-500">{note}</p>}</div>;
}
