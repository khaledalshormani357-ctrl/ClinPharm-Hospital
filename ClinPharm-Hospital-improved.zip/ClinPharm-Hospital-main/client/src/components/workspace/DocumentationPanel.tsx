import { useState } from "react";
import { FileText, FlaskConical, Plus, Stethoscope, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { EVIDENCE_LEVELS, buildSoapNote, evidenceGate, missingSoapSections } from "@/lib/clinical-engine";
import type { useCloudClinicalRecords } from "@/hooks/useCloudClinicalRecords";

type Records = ReturnType<typeof useCloudClinicalRecords>;
const area = "min-h-24 w-full rounded-xl border border-slate-200 bg-white p-3 text-sm outline-none focus-visible:border-teal-500 focus-visible:ring-2 focus-visible:ring-teal-200";
const selectClass = "h-9 rounded-md border border-slate-200 bg-white px-2 text-sm";
const fail = (error: unknown) => toast.error(error instanceof Error ? error.message : "Something went wrong");

export function InterventionsPanel({ records }: { records: Records }) {
  const [soap, setSoap] = useState({ subjective: "", objective: "", assessment: "", plan: "" });
  const [type, setType] = useState("Medication review");
  const [url, setUrl] = useState("");
  const [level, setLevel] = useState("");
  const [insufficient, setInsufficient] = useState(false);
  const [busy, setBusy] = useState(false);

  const hasEvidence = evidenceGate(url, level);
  const missing = missingSoapSections(soap);
  const canSave = missing.length === 0 && (hasEvidence || insufficient);

  const save = async () => {
    setBusy(true);
    try {
      const note = buildSoapNote({ ...soap, source: hasEvidence ? `${url.trim()} (${level})` : undefined });
      await records.createIntervention({ patient_id: null, intervention_type: type, soap_note: note, evidence_url: hasEvidence ? url.trim() : undefined, evidence_level: hasEvidence ? level : undefined, status: "draft" });
      setSoap({ subjective: "", objective: "", assessment: "", plan: "" }); setUrl(""); setLevel(""); setInsufficient(false);
      toast.success("Intervention saved as draft");
    } catch (error) { fail(error); } finally { setBusy(false); }
  };

  const setStatus = async (id: string, status: "draft" | "submitted" | "accepted" | "rejected") => { try { await records.updateIntervention(id, { status }); } catch (error) { fail(error); } };

  return (
    <Card className="border-slate-200 shadow-sm xl:col-span-2">
      <CardHeader><p className="eyebrow">Clinical documentation</p><CardTitle className="flex items-center gap-2"><FileText className="h-5 w-5 text-teal-700" />SOAP note &amp; intervention log</CardTitle></CardHeader>
      <CardContent>
        <label className="field-label mb-3 max-w-xs">Intervention type<Input value={type} onChange={(e) => setType(e.target.value)} /></label>
        <div className="grid gap-3 sm:grid-cols-2">
          {(["subjective", "objective", "assessment", "plan"] as const).map((key) => <label key={key} className="field-label capitalize">{key}<textarea className={area} value={soap[key]} onChange={(e) => setSoap({ ...soap, [key]: e.target.value })} /></label>)}
        </div>
        <div className="mt-4 grid gap-3 rounded-xl bg-slate-50 p-4 sm:grid-cols-2">
          <label className="field-label">Evidence source URL<Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://…" inputMode="url" /></label>
          <label className="field-label">Evidence level<select className={selectClass} value={level} onChange={(e) => setLevel(e.target.value)}><option value="">Select…</option>{EVIDENCE_LEVELS.map((l) => <option key={l}>{l}</option>)}</select></label>
          <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 sm:col-span-2"><input type="checkbox" checked={insufficient} onChange={(e) => setInsufficient(e.target.checked)} /> No suitable evidence — record “Insufficient evidence”</label>
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-slate-500">{missing.length > 0 ? `Missing: ${missing.join(", ")}` : !canSave ? "Add a valid source and evidence level, or mark insufficient evidence." : "Ready to save."}</p>
          <Button onClick={() => void save()} disabled={!canSave || busy} className="rounded-xl bg-[#102b2c] text-white"><Plus className="mr-2 h-4 w-4" />Save intervention</Button>
        </div>

        <h3 className="mt-8 text-sm font-bold text-slate-800">Saved interventions ({records.interventions.length})</h3>
        <ul className="mt-3 space-y-3">
          {records.interventions.map((item) => (
            <li key={item.id} className="rounded-xl border border-slate-200 p-4">
              <div className="flex flex-wrap items-center justify-between gap-2"><p className="text-sm font-bold">{item.intervention_type}</p>
                <select aria-label="Intervention status" className={selectClass} value={item.status ?? "draft"} onChange={(e) => void setStatus(item.id!, e.target.value as "draft")}><option value="draft">Draft</option><option value="submitted">Submitted</option><option value="accepted">Accepted</option><option value="rejected">Rejected</option></select></div>
              {item.soap_note && <pre className="mt-2 max-h-40 overflow-auto whitespace-pre-wrap text-xs leading-5 text-slate-600">{item.soap_note}</pre>}
              <p className="mt-2 text-[10px] text-slate-400">{item.updated_at ? new Date(item.updated_at).toLocaleString() : ""}</p>
            </li>
          ))}
          {records.interventions.length === 0 && <li className="text-sm text-slate-500">No interventions yet.</li>}
        </ul>
      </CardContent>
    </Card>
  );
}

export function MedicationReviewPanel({ records }: { records: Records }) {
  const [form, setForm] = useState({ indication: "", effectiveness: "", safety: "" });
  const save = async () => {
    try { await records.saveMedicationReview({ patient_id: null, ...form, status: "draft" }); setForm({ indication: "", effectiveness: "", safety: "" }); toast.success("Review saved"); } catch (error) { fail(error); }
  };
  const remove = async (id: string) => { if (!window.confirm("Delete this medication review?")) return; try { await records.deleteMedicationReview(id); } catch (error) { fail(error); } };
  return (
    <Card className="border-slate-200 shadow-sm xl:col-span-2">
      <CardHeader><p className="eyebrow">Medication review</p><CardTitle className="flex items-center gap-2"><FlaskConical className="h-5 w-5 text-teal-700" />Structured review (indication · effectiveness · safety)</CardTitle></CardHeader>
      <CardContent>
        <div className="grid gap-3 sm:grid-cols-3">
          <label className="field-label">Indication<Input value={form.indication} onChange={(e) => setForm({ ...form, indication: e.target.value })} /></label>
          <label className="field-label">Effectiveness<Input value={form.effectiveness} onChange={(e) => setForm({ ...form, effectiveness: e.target.value })} placeholder="Target / response" /></label>
          <label className="field-label">Safety<Input value={form.safety} onChange={(e) => setForm({ ...form, safety: e.target.value })} placeholder="Risk / monitoring" /></label>
        </div>
        <Button onClick={() => void save()} disabled={!form.indication.trim()} className="mt-4 rounded-xl bg-[#102b2c] text-white">Save review</Button>
        <ul className="mt-6 space-y-2">
          {records.medicationReviews.map((review) => <li key={review.id} className="flex items-start justify-between gap-3 rounded-xl border border-slate-200 p-3 text-sm"><div><p className="font-bold">{review.indication}</p><p className="text-xs text-slate-500">{[review.effectiveness, review.safety].filter(Boolean).join(" · ") || "—"}</p></div><button aria-label="Delete review" onClick={() => void remove(review.id!)} className="text-slate-400 hover:text-rose-600"><Trash2 className="h-4 w-4" /></button></li>)}
          {records.medicationReviews.length === 0 && <li className="text-sm text-slate-500">No reviews yet.</li>}
        </ul>
      </CardContent>
    </Card>
  );
}

export function CasesPanel({ records }: { records: Records }) {
  const [title, setTitle] = useState("");
  const create = async () => { try { await records.createCase({ title: title.trim(), current_step: 0, source_verified: false, patient_id: null, data: {} }); setTitle(""); } catch (error) { fail(error); } };
  const remove = async (id: string) => { if (!window.confirm("Delete this case?")) return; try { await records.deleteCase(id); } catch (error) { fail(error); } };
  return (
    <Card className="border-teal-200 bg-teal-50/50 shadow-sm xl:col-span-2">
      <CardHeader><p className="eyebrow">Cases</p><CardTitle className="flex items-center gap-2"><Stethoscope className="h-5 w-5 text-teal-700" />Clinical cases</CardTitle></CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2"><Input className="max-w-sm bg-white" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Case title" aria-label="Case title" /><Button onClick={() => void create()} disabled={!title.trim()} className="rounded-xl bg-[#102b2c] text-white"><Plus className="mr-2 h-4 w-4" />Create case</Button></div>
        <ul className="mt-5 space-y-2">
          {records.cases.map((c) => <li key={c.id} className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-3 text-sm"><div><p className="font-bold">{c.title}</p><p className="text-xs text-slate-500">Step {(c.current_step ?? 0) + 1} of 10 {c.source_verified && <Badge className="ml-2 border-0 bg-teal-100 text-[10px] text-teal-800">source verified</Badge>}</p></div><button aria-label="Delete case" onClick={() => void remove(c.id!)} className="text-slate-400 hover:text-rose-600"><Trash2 className="h-4 w-4" /></button></li>)}
          {records.cases.length === 0 && <li className="text-sm text-slate-500">No cases yet.</li>}
        </ul>
      </CardContent>
    </Card>
  );
}
