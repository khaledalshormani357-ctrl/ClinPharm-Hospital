import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { Activity, AlertTriangle, ArrowRight, BookOpen, BrainCircuit, Calculator, ChevronDown, ClipboardCheck, FileText, FlaskConical, GraduationCap, HeartPulse, LayoutDashboard, MessageSquareText, Pill, Plus, Search, ShieldCheck, Sparkles, Stethoscope, Target, Users, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useSessionUser } from "@/lib/supabase/useSessionUser";
import { useCloudPatients } from "@/hooks/useCloudPatients";
import { useCloudClinicalRecords } from "@/hooks/useCloudClinicalRecords";
import WorkspaceFeature from "@/components/WorkspaceFeature";
import SupabaseAuthPanel from "@/components/SupabaseAuthPanel";
import CopilotDialog, { COPILOT_STEPS, type AssessmentSummary } from "@/components/CopilotDialog";

type Module = { label: string; icon: typeof LayoutDashboard; tone: string; description: string };

const modules: Module[] = [
  { label: "Patients", icon: Users, tone: "teal", description: "Patients you are following" },
  { label: "Clinical copilot", icon: BrainCircuit, tone: "violet", description: "Structured patient assessment workflow" },
  { label: "Interventions", icon: ClipboardCheck, tone: "amber", description: "Document SOAP notes and interventions" },
  { label: "Reconciliation", icon: Pill, tone: "blue", description: "Compare home medicines with current orders" },
  { label: "Drug information", icon: FlaskConical, tone: "rose", description: "Evidence-linked sources" },
  { label: "Calculators", icon: Calculator, tone: "indigo", description: "CrCl, eGFR, body weights, Child-Pugh" },
  { label: "Guidelines", icon: BookOpen, tone: "cyan", description: "Guideline finder with source tiers" },
  { label: "Training hub", icon: GraduationCap, tone: "orange", description: "Trainer–student supervision and feedback" },
];

const workspaceNav: Array<[string, typeof LayoutDashboard]> = [["Overview", LayoutDashboard], ["Patients", Users], ["Clinical copilot", BrainCircuit], ["Interventions", ClipboardCheck], ["Medication review", Pill], ["Reconciliation", FileText], ["Alerts", AlertTriangle]];
const toolsNav: Array<[string, typeof LayoutDashboard]> = [["Drug information", FlaskConical], ["Calculators", Calculator], ["Guidelines", BookOpen], ["Training hub", GraduationCap], ["Clinical logbook", FileText], ["Cases", Stethoscope], ["Questions", MessageSquareText], ["Progress", Target]];

const greeting = () => { const hour = new Date().getHours(); return hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening"; };

type PatientRow = { id: string; initials: string; name: string; ward: string; issue: string; status: string; color: string };

function SectionTitle({ eyebrow, title, action, onAction }: { eyebrow: string; title: string; action?: string; onAction?: () => void }) {
  return (
    <div className="flex items-end justify-between gap-4">
      <div><p className="eyebrow">{eyebrow}</p><h2 className="section-title">{title}</h2></div>
      {action && <button onClick={onAction} className="text-sm font-semibold text-teal-700 hover:text-teal-900">{action} <ArrowRight className="ml-1 inline h-4 w-4" /></button>}
    </div>
  );
}

function NavButton({ label, icon: Icon, active, onClick }: { label: string; icon: typeof LayoutDashboard; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} aria-current={active ? "page" : undefined} className={`nav-item ${active ? "nav-item-active" : ""}`}>
      <span className="grid h-8 w-8 place-items-center rounded-lg bg-white/5"><Icon className="h-4 w-4" /></span>{label}
    </button>
  );
}

export default function Home() {
  const { user, loading } = useSessionUser();
  const { patients: cloudPatients, syncState, pendingCount, createPatient, refresh: refreshCloud } = useCloudPatients();
  const records = useCloudClinicalRecords();
  const [activeModule, setActiveModule] = useState("Overview");
  const [copilotOpen, setCopilotOpen] = useState(false);
  const [copilotKey, setCopilotKey] = useState(0);
  const [search, setSearch] = useState("");
  const [alertOpen, setAlertOpen] = useState(true);
  const [assessment, setAssessment] = useState<AssessmentSummary | null>(null);
  const [navOpen, setNavOpen] = useState(false);

  const patients: PatientRow[] = useMemo(() => cloudPatients.map(({ id, initials, name, ward, issue, status, color }) => ({ id, initials, name, ward, issue, status, color })), [cloudPatients]);
  const filteredPatients = useMemo(() => patients.filter((patient) => `${patient.name} ${patient.id} ${patient.issue} ${patient.ward}`.toLowerCase().includes(search.toLowerCase())), [patients, search]);
  const highProblems = assessment?.problems.filter((problem) => problem.severity === "high") ?? [];
  const signedIn = Boolean(user);
  const openInterventions = records.interventions.filter((item) => item.status === "draft" || item.status === "submitted").length;
  const acceptedInterventions = records.interventions.filter((item) => item.status === "accepted").length;

  useEffect(() => { document.title = "ClinPharm Hospital · Clinical workspace"; }, []);
  const handleUpdate = useCallback((summary: AssessmentSummary) => setAssessment(summary), []);
  const closeCopilot = useCallback(() => setCopilotOpen(false), []);
  const go = (module: string) => { setActiveModule(module); setNavOpen(false); if (module === "Clinical copilot") setCopilotOpen(true); };

  const savePatient = async (draft: { id: string; initials: string; ward: string }) => {
    await createPatient({ id: draft.id, initials: draft.initials, name: draft.initials, ward: draft.ward || "Unassigned", issue: "New clinical assessment", status: "Needs review", color: "bg-teal-100 text-teal-700" });
  };

  const completeCase = async (summary: AssessmentSummary) => {
    if (!signedIn) return false;
    await records.createCase({ title: summary.title, current_step: COPILOT_STEPS.length - 1, source_verified: summary.sourceVerified, patient_id: null, data: summary.data });
    await records.createIntervention({ patient_id: null, intervention_type: "Pharmacist assessment", soap_note: summary.soapNote, evidence_url: summary.sourceUrl, evidence_level: summary.evidenceLevel, status: "draft" });
    return true;
  };

  if (loading) return <div className="grid min-h-screen place-items-center bg-[#f5f8f7]" role="status" aria-label="Loading"><Activity className="h-6 w-6 animate-pulse text-teal-700" /></div>;

  const sidebar = (
    <>
      <div className="flex h-24 items-center gap-3 border-b border-white/10 px-7">
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-[#bdebdc] text-[#102b2c]"><HeartPulse className="h-6 w-6" /></div>
        <div><div className="font-display text-lg font-bold tracking-tight">ClinPharm</div><div className="text-[10px] uppercase tracking-[0.18em] text-[#9ec2bd]">Hospital intelligence</div></div>
      </div>
      <nav aria-label="Workspace" className="px-5 py-7"><p className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[#719997]">Workspace</p>{workspaceNav.map(([label, icon]) => <NavButton key={label} label={label} icon={icon} active={activeModule === label} onClick={() => go(label)} />)}</nav>
      <nav aria-label="Learning and tools" className="mt-auto px-5 pb-7"><p className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[#719997]">Learning &amp; tools</p>{toolsNav.map(([label, icon]) => <NavButton key={label} label={label} icon={icon} active={activeModule === label} onClick={() => go(label)} />)}</nav>
    </>
  );

  return (
    <div className="min-h-screen bg-[#f5f8f7] text-slate-900">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[250px] flex-col overflow-y-auto border-r border-slate-200 bg-[#102b2c] text-white lg:flex">{sidebar}</aside>
      {navOpen && <div className="fixed inset-0 z-40 lg:hidden"><button aria-label="Close menu" className="absolute inset-0 bg-black/40" onClick={() => setNavOpen(false)} /><aside className="absolute inset-y-0 left-0 flex w-[270px] flex-col overflow-y-auto bg-[#102b2c] text-white">{sidebar}</aside></div>}

      <main className="lg:pl-[250px]">
        <header className="sticky top-0 z-20 border-b border-slate-200/80 bg-[#f5f8f7]/90 px-5 py-4 backdrop-blur-xl sm:px-8">
          <div className="mx-auto flex max-w-[1500px] items-center justify-between gap-4">
            <button className="flex items-center gap-3 lg:hidden" onClick={() => setNavOpen(true)} aria-label="Open menu"><span className="grid h-9 w-9 place-items-center rounded-xl bg-[#102b2c] text-[#bdebdc]"><HeartPulse className="h-5 w-5" /></span><span className="font-display font-bold">ClinPharm</span></button>
            <div className="hidden items-center gap-2 text-sm text-slate-500 sm:flex">
              <span className="font-semibold text-slate-900">Clinical workspace</span><span>/</span><span>{activeModule}</span>
              <span role="status" className={`ml-2 rounded-full px-2 py-1 text-[10px] font-bold ${syncState === "synced" ? "bg-[#eaf7f2] text-teal-800" : syncState === "failed" ? "bg-rose-100 text-rose-700" : "bg-amber-100 text-amber-800"}`}>Cloud {syncState}{pendingCount > 0 ? ` · ${pendingCount} pending` : ""}</span>
            </div>
            <div className="flex flex-1 items-center justify-end gap-3">
              <div className="relative hidden w-full max-w-[290px] md:block"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" /><Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search patients…" aria-label="Search patients" className="h-10 rounded-xl border-slate-200 bg-white pl-9 shadow-sm" /></div>
              <button aria-label="Open safety alerts" onClick={() => go("Alerts")} className="relative grid h-10 w-10 place-items-center rounded-xl border border-slate-200 bg-white text-slate-600 shadow-sm"><AlertTriangle className="h-4 w-4" />{highProblems.length > 0 && <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-rose-500 ring-2 ring-white" />}</button>
              <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white py-1.5 pl-1.5 pr-3 shadow-sm"><div className="grid h-7 w-7 place-items-center rounded-lg bg-[#dff4ed] text-xs font-bold uppercase text-teal-800">{user?.name.slice(0, 1) ?? "?"}</div><span className="hidden text-sm font-semibold sm:inline">{user?.name ?? "Signed out"}</span><ChevronDown className="h-3.5 w-3.5 text-slate-400" /></div>
            </div>
          </div>
        </header>

        <div className="mx-auto max-w-[1500px] px-5 pb-12 pt-8 sm:px-8">
          <div className="mb-5 max-w-xl"><SupabaseAuthPanel syncState={syncState} onRetry={() => void refreshCloud()} /></div>

          {activeModule !== "Overview" && <div className="mb-8 rounded-2xl border border-[#cfe5df] bg-white p-6 shadow-sm"><div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center"><div><p className="eyebrow">Clinical workspace / {activeModule}</p><h2 className="mt-1 font-display text-2xl font-extrabold tracking-[-0.03em]">{activeModule}</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">Built around evidence traceability, patient safety and an auditable reasoning trail.</p></div><Button onClick={() => setActiveModule("Overview")} variant="outline" className="rounded-xl">Back to overview</Button></div></div>}

          <WorkspaceFeature activeModule={activeModule} liveProblems={assessment?.problems ?? []} signedIn={signedIn} userId={user?.id ?? null} />

          {activeModule === "Patients" && <PatientsTable patients={filteredPatients} total={patients.length} />}

          {(activeModule === "Overview" || activeModule === "Clinical copilot") && <>
            <div className="mb-8 mt-2 flex flex-col justify-between gap-5 md:flex-row md:items-end">
              <div><p className="eyebrow">{new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}</p><h1 className="hero-title">{greeting()}, <span>{user?.name ?? "clinician"}.</span></h1><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">Review priority issues, continue your assessments and keep every recommendation traceable to its evidence.</p></div>
              <div className="flex gap-2">
                {assessment && <Button onClick={() => setCopilotOpen(true)} variant="outline" className="h-12 rounded-xl px-5 font-semibold">Resume assessment</Button>}
                <Button onClick={() => { setCopilotKey((k) => k + 1); setAssessment(null); setCopilotOpen(true); }} className="h-12 rounded-xl bg-[#102b2c] px-5 font-semibold text-white shadow-[0_8px_20px_rgba(16,43,44,0.18)] hover:bg-[#1a4a4b]"><Plus className="mr-2 h-4 w-4" /> New patient assessment</Button>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <StatCard accent="teal" icon={<Users className="h-5 w-5" />} iconClass="bg-[#dff4ed] text-teal-800" value={String(patients.length)} label="Patients" note={pendingCount > 0 ? `${pendingCount} to sync` : signedIn ? "synced" : "local only"} />
              <StatCard accent="violet" icon={<ClipboardCheck className="h-5 w-5" />} iconClass="bg-violet-100 text-violet-700" value={signedIn ? String(openInterventions) : "—"} label="Open interventions" note={signedIn ? `${acceptedInterventions} accepted` : "sign in"} />
              <StatCard accent="amber" icon={<BrainCircuit className="h-5 w-5" />} iconClass="bg-amber-100 text-amber-700" value={signedIn ? String(records.cases.length) : "—"} label="Saved cases" note={signedIn ? "cloud logbook" : "sign in"} />
              <StatCard accent="rose" icon={<Target className="h-5 w-5" />} iconClass="bg-rose-100 text-rose-700" value={signedIn ? String(records.medicationReviews.length) : "—"} label="Medication reviews" note={signedIn ? "cloud" : "sign in"} />
            </div>

            <div className="mt-9 grid gap-6 xl:grid-cols-[1.45fr_0.95fr]">
              <section>
                <SectionTitle eyebrow="Clinical priority" title="Patients" action="View all" onAction={() => setActiveModule("Patients")} />
                <PatientsTable patients={filteredPatients.slice(0, 6)} total={patients.length} className="mt-4" />
              </section>
              <section>
                <SectionTitle eyebrow="Safety first" title="Current assessment alerts" action="Alert center" onAction={() => setActiveModule("Alerts")} />
                <div className="mt-4 space-y-3" aria-live="polite">
                  {(assessment?.problems ?? []).slice(0, 4).map((problem, index) => (
                    <div key={`${problem.rule}-${index}`} className="alert-card">
                      <div className={`mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl ${problem.severity === "high" ? "bg-rose-100 text-rose-600" : "bg-amber-100 text-amber-700"}`}><AlertTriangle className="h-4 w-4" /></div>
                      <div className="min-w-0"><p className="truncate text-sm font-bold text-slate-800">{problem.title}</p><p className="mt-1 text-xs leading-5 text-slate-500">{problem.detail}</p></div>
                    </div>
                  ))}
                  {(!assessment || assessment.problems.length === 0) && <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500"><Sparkles className="mb-2 h-4 w-4 text-teal-600" />Alerts appear here from the therapy you enter in a patient assessment. No data has been screened yet.</div>}
                </div>
              </section>
            </div>

            <div className="mt-10"><SectionTitle eyebrow="Workspace modules" title="Built for the clinical workflow" />
              <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{modules.map((module) => <button key={module.label} onClick={() => go(module.label)} className="module-card group text-left"><div className={`module-icon tone-${module.tone}`}><module.icon className="h-5 w-5" /></div><div className="mt-4 flex items-center justify-between gap-2"><h3 className="text-sm font-bold text-slate-800">{module.label}</h3><ArrowRight className="h-4 w-4 text-slate-300 transition group-hover:translate-x-1 group-hover:text-teal-600" /></div><p className="mt-1 text-xs leading-5 text-slate-500">{module.description}</p></button>)}</div>
            </div>
          </>}

          <div className="mt-10 rounded-2xl border border-[#cfe5df] bg-[#eaf7f2] px-5 py-4 text-xs leading-5 text-[#315b56]"><div className="flex items-start gap-3"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-teal-700" /><p><strong>Clinical safety notice:</strong> ClinPharm is a decision-support and educational tool. It does not replace clinical judgment, institutional protocols, licensed drug references or the treating team. Screening rules are a limited seed set: the absence of an alert never means a regimen is safe. Use de-identified data only unless your institution has approved otherwise.</p></div></div>
        </div>
      </main>

      {alertOpen && highProblems.length > 0 && <div role="alert" className="fixed bottom-5 right-5 z-40 hidden w-[340px] rounded-2xl border border-rose-200 bg-white p-4 shadow-[0_20px_60px_rgba(15,23,42,0.16)] sm:block"><div className="flex items-start gap-3"><div className="grid h-9 w-9 place-items-center rounded-xl bg-rose-100 text-rose-600"><AlertTriangle className="h-4 w-4" /></div><div className="flex-1"><div className="flex items-center justify-between"><p className="text-sm font-bold">Safety alert</p><button aria-label="Dismiss safety alert" onClick={() => setAlertOpen(false)}><X className="h-4 w-4 text-slate-400" /></button></div><p className="mt-1 text-xs leading-5 text-slate-500">{highProblems.length} high-severity problem{highProblems.length === 1 ? "" : "s"} in the current assessment need verification.</p><button onClick={() => go("Alerts")} className="mt-3 text-xs font-bold text-rose-600">Review alerts <ArrowRight className="ml-1 inline h-3 w-3" /></button></div></div></div>}

      <CopilotDialog key={copilotKey} open={copilotOpen} onClose={closeCopilot} onUpdate={handleUpdate} onSavePatient={savePatient} onComplete={async (summary) => { try { return await completeCase(summary); } catch (error) { toast.error(error instanceof Error ? error.message : "Could not save the case"); return false; } }} />
    </div>
  );
}

function StatCard({ accent, icon, iconClass, value, label, note }: { accent: string; icon: ReactNode; iconClass: string; value: string; label: string; note: string }) {
  return <Card className={`stat-card stat-accent-${accent}`}><CardContent className="p-5"><div className="mb-6 flex items-start justify-between"><div className={`stat-icon ${iconClass}`}>{icon}</div><span className="trend trend-neutral">{note}</span></div><p className="metric">{value}</p><p className="mt-1 text-sm text-slate-500">{label}</p></CardContent></Card>;
}

function PatientsTable({ patients, total, className = "" }: { patients: PatientRow[]; total: number; className?: string }) {
  return (
    <div className={`overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm ${className}`}>
      <div className="grid grid-cols-[1.45fr_1fr_1fr_auto] border-b border-slate-100 bg-slate-50/70 px-5 py-3 text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400"><span>Patient</span><span>Location</span><span>Clinical focus</span><span>Status</span></div>
      {patients.map((patient) => (
        <div key={patient.id} className="grid grid-cols-[1.45fr_1fr_1fr_auto] items-center gap-3 border-b border-slate-100 px-5 py-4 last:border-0">
          <div className="flex items-center gap-3"><div className={`grid h-9 w-9 place-items-center rounded-xl text-xs font-bold ${patient.color}`}>{patient.initials}</div><div><p className="text-sm font-bold text-slate-800">{patient.name}</p><p className="text-xs text-slate-400">{patient.id}</p></div></div>
          <span className="text-xs font-medium text-slate-500">{patient.ward}</span>
          <span className="text-xs font-semibold text-slate-700">{patient.issue}</span>
          <Badge className="whitespace-nowrap border-0 bg-slate-100 text-[10px] text-slate-600">{patient.status}</Badge>
        </div>
      ))}
      {patients.length === 0 && <div className="p-8 text-center text-sm text-slate-500">{total === 0 ? "No patients yet. Start a patient assessment to add one." : "No patient matches this search."}</div>}
    </div>
  );
}
